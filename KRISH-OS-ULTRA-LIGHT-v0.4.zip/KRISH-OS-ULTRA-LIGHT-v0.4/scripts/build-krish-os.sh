#!/bin/bash
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Please run this build script as root (or with sudo)." >&2
  exit 1
fi

if [ ! -r /etc/os-release ]; then
  echo "Cannot identify the build environment." >&2
  exit 1
fi
. /etc/os-release
if [ "${ID:-}" != "debian" ]; then
  echo "Build inside Debian 13 (Trixie), for example using the supplied GitHub Actions workflow." >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y live-build debootstrap xorriso squashfs-tools ca-certificates

lb clean --purge || true
lb config \
  --mode debian \
  --distribution trixie \
  --architectures amd64 \
  --binary-images iso-hybrid \
  --bootloaders "grub-efi grub-pc" \
  --archive-areas "main contrib non-free non-free-firmware" \
  --apt-recommends true

lb build
