#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
test -s "$ROOT/config/package-lists/krish-os.list.chroot"
test -s "$ROOT/config/includes.chroot/etc/skel/.config/openbox/autostart"
test -s "$ROOT/config/includes.chroot/etc/lightdm/lightdm.conf.d/50-krish-os.conf"
test -s "$ROOT/config/includes.chroot/usr/share/xsessions/krish-openbox.desktop"
grep -q '^openbox$' "$ROOT/config/package-lists/krish-os.list.chroot"
grep -q '^lightdm$' "$ROOT/config/package-lists/krish-os.list.chroot"
grep -q 'user-session=krish-openbox' "$ROOT/config/includes.chroot/etc/lightdm/lightdm.conf.d/50-krish-os.conf"
echo "KRISH OS v0.4 source checks passed."
